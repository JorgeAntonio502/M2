Fichiers de données utilisées pour la figure du cas T = 3500K
ouvrir "plot-3500K.gnu" depuis gnuplot
