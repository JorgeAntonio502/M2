Fichiers de données utilisées pour les figures
ouvrir "plot-300K.gnu" depuis gnuplot
