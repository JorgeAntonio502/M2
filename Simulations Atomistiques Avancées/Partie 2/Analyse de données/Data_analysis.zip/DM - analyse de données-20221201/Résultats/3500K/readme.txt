Fichiers de données utilisées pour la figure du cas T = 3500K
ouvrir "plot.gnu" depuis gnuplot
