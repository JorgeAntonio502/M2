Fichiers de données utilisées pour les figures
ouvrir "plot.gnu" depuis gnuplot
